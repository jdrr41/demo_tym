
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { motion } from "framer-motion";

const data = [
  { day: "Lun", gratitude: 8 },
  { day: "Mar", gratitude: 7 },
  { day: "Mié", gratitude: 9 },
  { day: "Jue", gratitude: 8 },
  { day: "Vie", gratitude: 10 },
  { day: "Sáb", gratitude: 6 },
  { day: "Dom", gratitude: 7 },
];

const App = () => {
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center py-6">
      {/* Header */}
      <header className="w-full px-6 mb-4">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center text-2xl font-bold text-gray-800"
        >
          Arigato Money
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center text-base text-gray-600 mt-1"
        >
          Transforma tu relación con el dinero
        </motion.div>
      </header>

      {/* Daily Gratitude Section */}
      <Card className="w-11/12 md:w-3/5 lg:w-1/2 mb-6">
        <CardContent>
          <h2 className="text-xl font-semibold mb-4">Registra tu Gratitud</h2>
          <p className="text-sm text-gray-600 mb-4">
            Anota tus emociones y reflexiones al recibir o gastar dinero.
          </p>
          <textarea
            className="w-full border border-gray-300 rounded-lg p-2 focus:outline-none focus:ring focus:ring-green-200"
            placeholder="Escribe tu experiencia del día..."
          />
          <Button className="mt-4 w-full bg-green-500 hover:bg-green-600 text-white">
            Guardar Reflexión
          </Button>
        </CardContent>
      </Card>

      {/* Progress Section */}
      <Card className="w-11/12 md:w-3/5 lg:w-1/2 mb-6">
        <CardContent>
          <h2 className="text-xl font-semibold mb-4">Tu Progreso</h2>
          <div className="w-full h-64">
            <ResponsiveContainer>
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="gratitude" stroke="#82ca9d" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Resources Section */}
      <Card className="w-11/12 md:w-3/5 lg:w-1/2 mb-6">
        <CardContent>
          <h2 className="text-xl font-semibold mb-4">Recursos</h2>
          <ul className="list-disc list-inside text-gray-600">
            <li className="mb-2">
              <a href="#" className="text-green-500 hover:underline">
                Aprende más sobre el Arigato Money
              </a>
            </li>
            <li className="mb-2">
              <a href="#" className="text-green-500 hover:underline">
                Consejos para mejorar tu gratitud financiera
              </a>
            </li>
            <li>
              <a href="#" className="text-green-500 hover:underline">
                Comunidad de usuarios
              </a>
            </li>
          </ul>
        </CardContent>
      </Card>

      {/* Footer */}
      <footer className="text-center text-gray-500 text-sm mt-6">
        © 2025 Arigato Money. Todos los derechos reservados.
      </footer>
    </div>
  );
};

export default App;
